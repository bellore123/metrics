from django.shortcuts import render

# Create your views here.
from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render

from cleaning.models import CleaningRequest

from .models import CleanerProfile


def cleaner_required(view):
    @wraps(view)
    @login_required
    def wrapper(request, *args, **kwargs):
        if request.user.role != "cleaner":
            return HttpResponseForbidden("Cleaner access only.")
        return view(request, *args, **kwargs)
    return wrapper


def get_cleaner(user):
    return get_object_or_404(CleanerProfile, user=user)


@cleaner_required
def cleaner_home(request):
    cleaner = get_cleaner(request.user)
    requests = CleaningRequest.objects.filter(
        assigned_cleaner=cleaner
    ).select_related("student__user", "hostel_allocation").order_by(
        "cleaning_date", "time_slot"
    )
    return render(
        request,
        "cleaners/home.html",
        {
            "cleaner": cleaner,
            "requests": requests,
            "active_count": requests.filter(
                status__in=["assigned", "in_progress"]
            ).count(),
            "completed_count": requests.filter(
                status__in=["completed", "confirmed"]
            ).count(),
        },
    )


@cleaner_required
def cleaner_request_detail(request, request_id):
    cleaner = get_cleaner(request.user)
    cleaning_request = get_object_or_404(
        CleaningRequest.objects.select_related(
            "student__user", "hostel_allocation"
        ),
        id=request_id,
        assigned_cleaner=cleaner,
    )
    return render(
        request,
        "cleaners/request_detail.html",
        {"cleaning_request": cleaning_request},
    )


def update_status(request, request_id, old_status, new_status, message):
    cleaner = get_cleaner(request.user)
    cleaning_request = get_object_or_404(
        CleaningRequest,
        id=request_id,
        assigned_cleaner=cleaner,
        status=old_status,
    )
    if request.method == "POST":
        cleaning_request.status = new_status
        cleaning_request.save()
        messages.success(request, message)
    return redirect("cleaner_request_detail", request_id=request_id)


@cleaner_required
def start_request(request, request_id):
    return update_status(
        request, request_id, "assigned", "in_progress", "Cleaning started."
    )


@cleaner_required
def complete_request(request, request_id):
    return update_status(
        request, request_id, "in_progress", "completed", "Cleaning marked complete."
    )
