from django.conf import settings
from django.db import models


HOSTEL_BLOCK_CHOICES = [
    ("MH A", "MH A - Albert Einstein"),
    ("MH B", "MH B - Swami Vivekananda"),
    (
        "MH B ANNEX",
        "MH B Annex - Swami Vivekananda"
    ),
    ("MH C", "MH C - Rabindranath Tagore"),
    ("MH D", "MH D - Nelson Mandela"),
    (
        "MH D ANNEX",
        "MH D Annex - Nelson Mandela"
    ),
    ("MH E", "MH E - Sir C.V. Raman"),
    ("MH F", "MH F - Ramanujam"),
    ("MH G", "MH G - Socrates"),
    ("MH H", "MH H - John F. Kennedy"),
    ("MH J", "MH J - John F. Kennedy"),
    (
        "MH K",
        "MH K - Dr. Sarvepalli Radhakrishnan"
    ),
    (
        "MH L",
        "MH L - Netaji Subhas Chandra Bose"
    ),
    (
        "MH M",
        "MH M - Quaid-E-Millat Muhammed Ismail"
    ),
    (
        "MH M ANNEX",
        "MH M Annex - Quaid-E-Millat Muhammed Ismail"
    ),
    ("MH N", "MH N - Charles Darwin"),
    (
        "MH N ANNEX",
        "MH N Annex - Charles Darwin"
    ),
    ("MH P", "MH P - Sardar Patel"),
    ("MH Q", "MH Q - Vajpayee Block"),
    (
        "MH R",
        "MH R - M. Karunanidhi"
    ),
    ("MH S", "MH S - Abdul Kalam Block"),
    (
        "MH T",
        "MH T - Jagadish Chandra Bose Block"
    ),
]


class StudentProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="student_profile"
    )

    def __str__(self):
        return self.user.email


class HostelAllocation(models.Model):
    student = models.ForeignKey(
        StudentProfile,
        on_delete=models.CASCADE,
        related_name="allocations"
    )

    hostel_name = models.CharField(
        max_length=100,
        default="VIT Men's Hostel"
    )

    block = models.CharField(
        max_length=20,
        choices=HOSTEL_BLOCK_CHOICES
    )

    room_number = models.CharField(
        max_length=10
    )

    academic_year = models.CharField(
        max_length=20
    )

    is_current = models.BooleanField(
        default=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:
        ordering = [
            "-is_current",
            "-created_at"
        ]

    def save(self, *args, **kwargs):
        # When a new current allocation is saved,
        # make all previous allocations inactive.
        if self.is_current:
            HostelAllocation.objects.filter(
                student=self.student,
                is_current=True
            ).exclude(
                pk=self.pk
            ).update(
                is_current=False
            )

        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"{self.student.user.email} - "
            f"{self.block} - Room {self.room_number}"
        )