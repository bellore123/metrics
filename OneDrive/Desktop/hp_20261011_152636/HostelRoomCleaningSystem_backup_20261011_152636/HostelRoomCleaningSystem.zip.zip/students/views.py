from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from cleaning.models import CleaningRequest, Feedback

from .forms import CleaningRequestForm, HostelAllocationForm
from .models import HostelAllocation, StudentProfile


def student_only(user):
    return getattr(user, "role", None) == "student"


# =========================================================
# STUDENT HOME
# =========================================================

@login_required
def student_home(request):
    if not student_only(request.user):
        messages.error(
            request,
            "You are not allowed to access the student portal.",
        )
        return redirect("dashboard")

    student_profile, created = StudentProfile.objects.get_or_create(
        user=request.user,
    )

    current_allocation = HostelAllocation.objects.filter(
        student=student_profile,
        is_current=True,
    ).first()

    if current_allocation is None:
        return redirect("student_hostel_setup")

    latest_requests = CleaningRequest.objects.filter(
        hostel_allocation=current_allocation,
    ).order_by("-created_at")[:5]

    context = {
        "student_profile": student_profile,
        "current_allocation": current_allocation,
        "latest_requests": latest_requests,
    }

    return render(
        request,
        "students/home.html",
        context,
    )


# =========================================================
# HOSTEL ROOM SETUP
# =========================================================

@login_required
def hostel_setup(request):
    if not student_only(request.user):
        messages.error(
            request,
            "You are not allowed to access the student portal.",
        )
        return redirect("dashboard")

    student_profile, created = StudentProfile.objects.get_or_create(
        user=request.user,
    )

    current_allocation = HostelAllocation.objects.filter(
        student=student_profile,
        is_current=True,
    ).first()

    if request.method == "POST":
        form = HostelAllocationForm(
            request.POST,
            instance=current_allocation,
        )

        if form.is_valid():
            allocation = form.save(commit=False)

            allocation.student = student_profile
            allocation.is_current = True

            allocation.save()

            messages.success(
                request,
                "Your hostel details have been saved successfully.",
            )

            return redirect("student_home")

    else:
        form = HostelAllocationForm(
            instance=current_allocation,
        )

    context = {
        "form": form,
        "student_profile": student_profile,
        "current_allocation": current_allocation,
    }

    return render(
        request,
        "students/hostel_setup.html",
        context,
    )


# =========================================================
# CREATE CLEANING REQUEST
# =========================================================

@login_required
def create_cleaning_request(request):
    if not student_only(request.user):
        messages.error(
            request,
            "You are not allowed to access the student portal.",
        )
        return redirect("dashboard")

    student_profile, created = StudentProfile.objects.get_or_create(
        user=request.user,
    )

    current_allocation = HostelAllocation.objects.filter(
        student=student_profile,
        is_current=True,
    ).first()

    if current_allocation is None:
        messages.warning(
            request,
            "Please add your hostel details first.",
        )
        return redirect("student_hostel_setup")

    if request.method == "POST":
        form = CleaningRequestForm(request.POST)

        if form.is_valid():
            cleaning_request = form.save(commit=False)

            cleaning_request.hostel_allocation = current_allocation
            cleaning_request.student = student_profile

            cleaning_request.save()

            messages.success(
                request,
                "Cleaning request created successfully.",
            )

            return redirect("student_requests")

    else:
        form = CleaningRequestForm()

    context = {
        "form": form,
        "student_profile": student_profile,
        "current_allocation": current_allocation,
    }

    return render(
        request,
        "students/create_request.html",
        context,
    )


# =========================================================
# STUDENT REQUEST LIST
# =========================================================

@login_required
def student_requests(request):
    if not student_only(request.user):
        messages.error(
            request,
            "You are not allowed to access the student portal.",
        )
        return redirect("dashboard")

    student_profile, created = StudentProfile.objects.get_or_create(
        user=request.user,
    )

    current_allocation = HostelAllocation.objects.filter(
        student=student_profile,
        is_current=True,
    ).first()

    cleaning_requests = CleaningRequest.objects.filter(
        hostel_allocation__student=student_profile,
    ).order_by("-created_at")

    selected_status = request.GET.get("status", "").strip()

    if selected_status:
        cleaning_requests = cleaning_requests.filter(
            status=selected_status,
        )

    context = {
        "student_profile": student_profile,
        "current_allocation": current_allocation,
        "requests": cleaning_requests,
        "selected_status": selected_status,
        "cleaning_request_statuses": CleaningRequest.STATUS_CHOICES,
    }

    return render(
        request,
        "students/my_requests.html",
        context,
    )


# =========================================================
# STUDENT REQUEST DETAIL
# =========================================================

@login_required
def student_request_detail(request, request_id):
    if not student_only(request.user):
        messages.error(
            request,
            "You are not allowed to access the student portal.",
        )
        return redirect("dashboard")

    student_profile, created = StudentProfile.objects.get_or_create(
        user=request.user,
    )

    cleaning_request = CleaningRequest.objects.filter(
        id=request_id,
        hostel_allocation__student=student_profile,
    ).first()

    if cleaning_request is None:
        messages.error(
            request,
            "Cleaning request not found.",
        )
        return redirect("student_requests")

    current_allocation = HostelAllocation.objects.filter(
        student=student_profile,
        is_current=True,
    ).first()

    context = {
        "student_profile": student_profile,
        "current_allocation": current_allocation,
        "cleaning_request": cleaning_request,
    }

    return render(
        request,
        "students/request_detail.html",
        context,
    )


# =========================================================
# CANCEL REQUEST
# =========================================================

@login_required
def cancel_request(request, request_id):
    if not student_only(request.user):
        messages.error(
            request,
            "You are not allowed to access the student portal.",
        )
        return redirect("dashboard")

    if request.method != "POST":
        return redirect(
            "student_request_detail",
            request_id=request_id,
        )

    cleaning_request = CleaningRequest.objects.filter(
        id=request_id,
        student__user=request.user,
        status="pending",
    ).first()

    if cleaning_request is None:
        messages.error(
            request,
            "This request cannot be cancelled.",
        )

        return redirect(
            "student_request_detail",
            request_id=request_id,
        )

    cleaning_request.status = "cancelled"

    cleaning_request.save(
        update_fields=[
            "status",
            "updated_at",
        ],
    )

    messages.success(
        request,
        "Cleaning request cancelled successfully.",
    )

    return redirect(
        "student_request_detail",
        request_id=request_id,
    )


# =========================================================
# SUBMIT FEEDBACK
# =========================================================

@login_required
def submit_feedback(request, request_id):
    if not student_only(request.user):
        messages.error(
            request,
            "You are not allowed to access the student portal.",
        )
        return redirect("dashboard")

    if request.method != "POST":
        return redirect(
            "student_request_detail",
            request_id=request_id,
        )

    cleaning_request = CleaningRequest.objects.filter(
        id=request_id,
        student__user=request.user,
        status="completed",
    ).first()

    if cleaning_request is None:
        messages.error(
            request,
            "This request is not ready for feedback.",
        )

        return redirect("student_requests")

    room_status = request.POST.get(
        "room_status",
        "",
    ).strip()

    if room_status not in {
        "cleaned",
        "not_cleaned",
    }:
        messages.error(
            request,
            "Select the room cleaning status.",
        )

        return redirect(
            "student_request_detail",
            request_id=request_id,
        )

    rating_value = request.POST.get(
        "rating",
        "",
    ).strip()

    valid_ratings = {
        "1",
        "2",
        "3",
        "4",
        "5",
    }

    rating = (
        int(rating_value)
        if rating_value in valid_ratings
        else None
    )

    comments = request.POST.get(
        "comments",
        "",
    ).strip()

    Feedback.objects.update_or_create(
        cleaning_request=cleaning_request,
        defaults={
            "room_status": room_status,
            "rating": rating,
            "comments": comments,
        },
    )

    if room_status == "cleaned":
        cleaning_request.status = "confirmed"
    else:
        cleaning_request.status = "not_cleaned"

    cleaning_request.save(
        update_fields=[
            "status",
            "updated_at",
        ],
    )

    messages.success(
        request,
        "Thank you. Your feedback has been recorded.",
    )

    return redirect(
        "student_request_detail",
        request_id=request_id,
    )