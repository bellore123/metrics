from django.db import models
from students.models import StudentProfile, HostelAllocation
from cleaners.models import CleanerProfile
from wardens.models import WardenProfile


class CleaningRequest(models.Model):
    TIME_SLOT_CHOICES = [
        ("09:00-10:00", "9:00 AM - 10:00 AM"),
        ("10:00-11:00", "10:00 AM - 11:00 AM"),
        ("14:00-15:00", "2:00 PM - 3:00 PM"),
        ("16:00-17:00", "4:00 PM - 5:00 PM"),
        ("18:00-19:00", "6:00 PM - 7:00 PM"),
    ]

    CLEANING_TYPE_CHOICES = [
        ("sweeping", "Sweeping"),
        ("mopping", "Mopping"),
        ("bathroom", "Bathroom Cleaning"),
        ("dusting", "Dusting"),
        ("full", "Full Cleaning"),
    ]

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("assigned", "Assigned"),
        ("in_progress", "In Progress"),
        ("completed", "Completed"),
        ("confirmed", "Confirmed by Student"),
        ("not_cleaned", "Not Cleaned"),
        ("cancelled", "Cancelled"),
        ("rejected", "Rejected"),
    ]

    student = models.ForeignKey(
        StudentProfile,
        on_delete=models.CASCADE,
        related_name="cleaning_requests"
    )

    hostel_allocation = models.ForeignKey(
        HostelAllocation,
        on_delete=models.PROTECT,
        related_name="cleaning_requests"
    )

    cleaning_date = models.DateField()
    time_slot = models.CharField(
        max_length=20,
        choices=TIME_SLOT_CHOICES
    )
    cleaning_type = models.CharField(
        max_length=20,
        choices=CLEANING_TYPE_CHOICES
    )
    remarks = models.TextField(blank=True)

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="pending"
    )

    assigned_cleaner = models.ForeignKey(
        CleanerProfile,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="assigned_requests"
    )

    assigned_by = models.ForeignKey(
        WardenProfile,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="assigned_requests"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return (
            f"{self.student.user.email} - "
            f"{self.hostel_allocation.block} "
            f"{self.hostel_allocation.room_number}"
        )


class Feedback(models.Model):
    ROOM_STATUS_CHOICES = [
        ("cleaned", "Room Cleaned"),
        ("not_cleaned", "Room Not Cleaned"),
    ]

    cleaning_request = models.OneToOneField(
        CleaningRequest,
        on_delete=models.CASCADE,
        related_name="feedback"
    )

    room_status = models.CharField(
        max_length=20,
        choices=ROOM_STATUS_CHOICES
    )
    rating = models.PositiveSmallIntegerField(
        null=True,
        blank=True
    )
    comments = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback - {self.cleaning_request}"
